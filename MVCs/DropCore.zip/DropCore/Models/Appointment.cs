﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DropCore.models
{
    public partial class Appointment
    {
        public int ApptId { get; set; }
        public DateTime DateAndTime { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
    }
}
